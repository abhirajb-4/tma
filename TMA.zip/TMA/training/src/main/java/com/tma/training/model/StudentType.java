package com.tma.training.model;

public enum StudentType {
    FRESHER,LATERAL
}
