package com.tma.training.controller;

import com.tma.training.model.Training;
import com.tma.training.service.TrainingService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/training")
@RequiredArgsConstructor
public class TrainingController {

    private final TrainingService trainingService;

    //ADD NEW TRAINING
    @PostMapping
    public ResponseEntity<?> createTraining(@RequestBody Training training){
        Training saved =  trainingService.createTraining(training);
        return new ResponseEntity<>(saved,HttpStatus.CREATED);
    }

    //GET ALL TRAINING
    @GetMapping
    public List<Training> getAllTraining(){
        return trainingService.getAllTraining();
    }

    @GetMapping("/{id}")
    public ResponseEntity<?> getTrainingById(@PathVariable Long id) {
       return trainingService.getTrainingById(id);
    }

    @GetMapping("/vendor/{vendorId}")
    public List<Training> getTrainingsByVendorId(@PathVariable Long vendorId) {
        return trainingService.getTrainingsByVendorId(vendorId);
    }

    //GET TRAINING BY VENDOR ID  AND DATE
    @GetMapping("/vendor/{vendorId}/start-date/{startDate}")
    public List<Training> getTrainingsByVendorAndStartDate(
            @PathVariable Long vendorId,
            @PathVariable String startDate) {
        // Convert startDate string to LocalDate
        LocalDate start = LocalDate.parse(startDate);
        return trainingService.getTrainingsByVendorAndStartDate(vendorId, start);
    }

    //ADD TRAINER TO TRAINING
    @PutMapping("{training-id}/trainer/{trainer-id}")
    public ResponseEntity<String> addTrainer(
            @RequestParam Long trainingId,
            @RequestParam Long trainerId){
        trainingService.addTrainer(trainingId,trainerId);
        return new ResponseEntity<>("Trainer added succesfully", HttpStatus.OK);
    }

    //DELETE TRAINING
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTraining(@PathVariable Long id) {
        trainingService.deleteTraining(id);
        return ResponseEntity.noContent().build();
    }

}
