package com.tma.training.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class VendorResponseDto {
    private Long id;

    private String vendorName;
    private String vendorEmail;
    private String vendorAddress;
    private String vendorPocName;
    private Long VendorPocPhone;
}
