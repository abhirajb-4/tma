package com.tma.training.service;

import com.tma.training.dto.VendorResponseDto;
import com.tma.training.exception.InvalidDateException;
import com.tma.training.model.Training;
import com.tma.training.repository.TrainingRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TrainingService {
    private final TrainingRepository trainingRepository;
    private final WebClient.Builder webClientBuilder;

    //ADD TRAINING
    public Training createTraining(Training training) {
        if(training.getStartDate().isAfter(training.getEndDate()) ){
            throw new InvalidDateException("Start date is wrong");
        }
        return trainingRepository.save(training);
    }

    //GET ALL TRAINING
    public List<Training> getAllTraining() {
        return trainingRepository.findAll();
    }

    public ResponseEntity<?> getTrainingById(Long id) {
        Optional<Training> training = trainingRepository.findById(id);
        if (training.isPresent()) {
            return new ResponseEntity<>(training.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>("Training Not Found", HttpStatus.NOT_FOUND);
        }
    }


    public List<Training> getTrainingsByVendorId(Long vendorId) {
        return trainingRepository.findByVendorId(vendorId);
    }


    public void deleteTraining(Long id) {
        trainingRepository.deleteById(id);
    }

    public List<Training> getTrainingsByVendorAndStartDate(Long vendorId, LocalDate startDate) {
        return trainingRepository.findByVendorIdAndStartDate(vendorId, startDate);
    }

    public void addTrainer(Long trainingId, Long trainerId) {

        Optional<Training> fetchedTraining = trainingRepository.findById(trainerId);
        if(fetchedTraining.isEmpty()){
            throw new IllegalArgumentException("Training id not found");
        }
        Training training = fetchedTraining.get();
        if(!training.getTrainers().contains(trainerId)){
            training.getTrainers().add(trainerId);
        }
        trainingRepository.save(training);
    }

}
