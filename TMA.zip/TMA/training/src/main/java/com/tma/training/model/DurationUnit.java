package com.tma.training.model;

public enum DurationUnit {
    HOURS,DAYS,MONTHS
}
