package com.tma.training.repository;

import com.tma.training.model.Training;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface TrainingRepository extends JpaRepository<Training,Long> {
    //GET TRAININGS BY VENDOR NAME
    List<Training> findByVendorName(String vendorName);

    // Get Trainings by start date
    List<Training> findByStartDate(LocalDate startDate);

    List<Training> findByVendorNameAndStartDate(String vendorName, LocalDate startDate);

    List<Training> findByVendorId(Long vendorId);
}

