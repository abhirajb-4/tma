package com.tma.training.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class Training {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long vendorId;
    private String name;
    private String vendorName;

    @ElementCollection
    //@CollectionTable(name = "training_skills", joinColumns = @JoinColumn(name = "training_id"))
    @Column(name = "skill")
    private List<String> skills;

    @ElementCollection
    //@CollectionTable(name = "training_skills", joinColumns = @JoinColumn(name = "training_id"))
    @Column(name = "trainer")
    private List<Long> trainers = new ArrayList<>();

    @Enumerated(EnumType.STRING)
    private DurationUnit durationUnit;

    private int durationValue;
    private LocalDate startDate;
    private LocalDate endDate;
    private int noOfStudents;
    private int noOfBatches;
    private int budget;
    private String toc;
    private String poc;
    private String email;
    private long phno;
    @Enumerated(EnumType.STRING)
    private StudentType studentType;

}
