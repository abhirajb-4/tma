package com.tma.trainer.controller;

import com.tma.trainer.dto.TrainerRequestDto;
import com.tma.trainer.model.Status;
import com.tma.trainer.model.Trainer;
import com.tma.trainer.service.TrainerService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/trainer")
@RequiredArgsConstructor
public class TrainerController {

    private final TrainerService trainerService;

    @PostMapping()
    public ResponseEntity<?> addTrainer(@RequestBody TrainerRequestDto trainer){
        Trainer savedTrainer = trainerService.addTrainer(trainer);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedTrainer);
    }

    //GET MAPPINGS
    @GetMapping
    public List<Trainer> getAllTrainers(){
        return trainerService.getAllTrainers();
    }
    //GET BY ID
    @GetMapping("/{trainerId}")
    public ResponseEntity<?> getTrainerByid(@PathVariable Long trainerId){
        Optional<Trainer> trainer = trainerService.getTrainerByid(trainerId);
        if(trainer.isPresent()){
            return new ResponseEntity<>(trainer, HttpStatus.OK);
        }
        else return new ResponseEntity<>("Trainer not found",HttpStatus.NOT_FOUND);
    }

    // GET TRAINER BY SKILLS AND AVAILABILITY
    @GetMapping("/search")
    public ResponseEntity<List<Trainer>> searchTrainers(
            @RequestParam String skills, // skills as a comma-separated string
            @RequestParam double maxSalary) {  // maxSalary as a parameter

        // Split the skills string into a list of strings
        List<String> skillList = List.of(skills.split(","));

        // Call the service to find trainers based on skills and max salary with 'AVAILABLE' status
        List<Trainer> trainers = trainerService.findTrainersBySkillsAndSalary(skillList, maxSalary);

        return ResponseEntity.ok(trainers);
    }
    @PutMapping("/assignTraining/")
    public ResponseEntity<String> assignToTraining(
            @RequestParam Long trainerId,
            @RequestParam Long trainingId){

        try {
            trainerService.assignTrainerToTraining(trainerId, trainingId); // Call the service method
            return ResponseEntity.status(HttpStatus.OK).body("Trainer successfully assigned to training");
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
        }
    }

}
