package com.tma.trainer.service;

import com.tma.trainer.model.Status;
import com.tma.trainer.model.Trainer;
import com.tma.trainer.repository.TrainerRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class TrainerService {

    private final TrainerRepository trainerRepository;

    //CREATE TRAINER
    public Trainer addTrainer(Trainer trainer) {
        return trainerRepository.save(trainer);
    }
    //GET FUNCTIONS
    public List<Trainer> getAllTrainers() {
        return trainerRepository.findAll();
    }

    public List<Trainer> findTrainersBySkillsAndSalary(List<String> skills, double maxSalary) {
        return trainerRepository.findBySkillsInAndStatusAndExpectedSalaryLessThanEqual(skills, Status.AVAILABLE, maxSalary);
    }

    public void assignTrainerToTraining(Long trainerId, Long trainingId) {
        Trainer trainer = trainerRepository.findById(trainerId).orElseThrow(() -> new IllegalArgumentException("Trainer not found"));
        trainer.setTrainingId(trainingId);
        trainerRepository.save(trainer);
    }

    public Optional<Trainer> getTrainerByid(Long trainerId) {
        return trainerRepository.findById(trainerId);
    }
}
