package com.tma.trainer.dto;

import com.tma.trainer.model.Status;

import java.util.List;

public record TrainerRequestDto(String name,
                                String email,
                                List<String> skills,
                                double expectedSalary,
                                Status status
        )
{
}
