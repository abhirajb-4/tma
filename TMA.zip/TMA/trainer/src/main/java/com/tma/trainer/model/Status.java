package com.tma.trainer.model;

public enum Status {
    AVAILABLE,
    NOT_AVAILABLE
}
