package com.tma.trainer.repository;

import com.tma.trainer.model.Status;
import com.tma.trainer.model.Trainer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface TrainerRepository extends JpaRepository<Trainer,Long> {

    // Find trainers by skills, status (AVAILABLE) and expected salary
    List<Trainer> findBySkillsInAndStatusAndExpectedSalaryLessThanEqual(List<String> skills, Status status, double maxSalary);
}
